﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    class Child : Person
    {

        public Child(string name, int age)
            : base(name, age)
        {

        }
    }
}
