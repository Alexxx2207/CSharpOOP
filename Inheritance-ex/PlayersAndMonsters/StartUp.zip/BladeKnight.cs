﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    class BladeKnight : DarkKnight
    {
        public BladeKnight(string u, int l) : base(u,l)
        {

        }
    }
}
