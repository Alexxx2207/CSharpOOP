﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    class Wizard : Hero
    {
        public Wizard(string u, int i) : base(u,i)
        {

        }
    }
}
