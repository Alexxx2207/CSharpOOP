﻿using System;
using System.Collections.Generic;
using System.Text;
namespace PizzaCalories.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string textLine);
    }
}
