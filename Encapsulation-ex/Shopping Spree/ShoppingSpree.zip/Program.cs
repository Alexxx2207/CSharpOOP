﻿using Shopping_Spree.Core;
using System;

namespace Shopping_Spree
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
