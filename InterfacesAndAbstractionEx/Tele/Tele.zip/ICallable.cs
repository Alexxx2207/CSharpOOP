﻿
namespace Tele
{
    interface ICallable
    {
        string Call(string phone);
    }
}
