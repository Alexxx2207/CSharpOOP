﻿namespace Tele
{
    interface IBrowseable
    {
        string Browse(string website);
    }
}
