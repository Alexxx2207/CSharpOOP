﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy.Interfaces
{
    public interface IMyList
    {
        public int Used { get; }
        int Add(string name);
        string Remove();
    }
}
