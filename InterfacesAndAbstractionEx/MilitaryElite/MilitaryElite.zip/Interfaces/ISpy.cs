﻿namespace MilitaryElite
{
    public interface ISpy
    {
        public int Code { get; }

    }
}