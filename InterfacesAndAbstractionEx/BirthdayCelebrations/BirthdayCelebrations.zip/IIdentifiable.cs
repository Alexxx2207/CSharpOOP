﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{   
    interface IIdentifiable
    {
        public string Id { get; set; }
    }
}
