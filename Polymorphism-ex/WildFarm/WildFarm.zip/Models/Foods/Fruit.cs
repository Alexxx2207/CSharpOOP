﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Interfaces;

namespace WildFarm.Models.Foods
{
    class Fruit : Food
    {
        public Fruit(int quaintity) : base(quaintity)
        {
        }
    }
}
