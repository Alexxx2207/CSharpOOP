﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Interfaces;

namespace WildFarm.Models.Foods
{
    class Seeds : Food
    {
        public Seeds(int quaintity) : base(quaintity)
        {
        }
    }
}
