﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Interfaces;

namespace WildFarm.Models.Foods
{
    class Vegetable : Food
    {
        public Vegetable(int quaintity) : base(quaintity)
        {
        }
    }
}
