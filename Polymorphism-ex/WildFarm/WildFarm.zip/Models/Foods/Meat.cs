﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Interfaces;

namespace WildFarm.Models.Foods
{
    class Meat : Food
    {
        public Meat(int quaintity) : base(quaintity)
        {
        }
    }
}
